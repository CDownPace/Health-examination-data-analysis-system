 /**
 * 操作权限处理
 * Copyright (c) 2019 Haoxinren
 */

import store from '@/store'

export default {
  inserted(el, binding, vnode) {
    return true
  }
}
