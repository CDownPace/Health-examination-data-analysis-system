package com.example.project.system.domain;

import lombok.Data;

@Data
public class SysLoginData {
    private Long uid;
    private String token;
}
